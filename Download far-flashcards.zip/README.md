# FAR Flashcards App

This is a simple web-based study tool to help users learn the **Federal Acquisition Regulation (FAR)** using:

- Flashcards
- Quiz mode
- Keyword search
- Local progress tracking

## 🔗 Live App

👉 [Link will appear here once deployed]

## 📦 Features

- Easy-to-use flashcard viewer
- Quiz mode with multiple-choice questions
- Search bar to filter by keyword
- Dashboard with mode switching
- Fully browser-based, no login required

## 💻 How to Use Locally

1. Download or clone this repo
2. Open `index.html` in any browser

## 🛠️ Built With

- HTML
- CSS
- JavaScript
- GitHub Pages

## 📬 Contact

Created by Oscar Garcia