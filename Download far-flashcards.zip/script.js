const flashcards = [
  {
    question: "What does FAR Part 1 cover?",
    answer: "The Federal Acquisition Regulations System – purpose, authority, arrangement."
  },
  {
    question: "What is the micro-purchase threshold?",
    answer: "$10,000 (general threshold)."
  },
  {
    question: "What is the Simplified Acquisition Threshold (SAT)?",
    answer: "$250,000 (see FAR 2.101)."
  },
  {
    question: "What does FAR Part 5 cover?",
    answer: "Publicizing contract actions."
  },
  {
    question: "What is covered in FAR Part 12?",
    answer: "Acquisition of commercial products and commercial services."
  },
  {
    question: "FAR Part 13 deals with what?",
    answer: "Simplified acquisition procedures."
  },
  {
    question: "What is a Contracting Officer’s Warrant?",
    answer: "Official authorization to obligate the government."
  }
];

let currentIndex = parseInt(localStorage.getItem("currentIndex")) || 0;

const questionEl = document.getElementById("question");
const answerEl = document.getElementById("answer");
const showAnswerBtn = document.getElementById("showAnswer");
const nextBtn = document.getElementById("next");
const prevBtn = document.getElementById("prev");
const searchInput = document.getElementById("searchInput");
const searchResults = document.getElementById("searchResults");

function showCard(index) {
  const card = flashcards[index];
  questionEl.textContent = card.question;
  answerEl.textContent = card.answer;
  answerEl.classList.add("hidden");
  localStorage.setItem("currentIndex", index);
}

showAnswerBtn.addEventListener("click", () => {
  answerEl.classList.toggle("hidden");
});

nextBtn.addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % flashcards.length;
  showCard(currentIndex);
});

prevBtn.addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + flashcards.length) % flashcards.length;
  showCard(currentIndex);
});

// === Quiz Mode ===
const quizQuestion = document.getElementById("quiz-question");
const quizOptions = document.getElementById("quiz-options");
const quizFeedback = document.getElementById("quiz-feedback");
const nextQuizBtn = document.getElementById("nextQuiz");

let quizIndex = 0;

function loadQuizQuestion() {
  const correct = flashcards[quizIndex];
  let choices = [...flashcards];
  choices = choices.sort(() => 0.5 - Math.random()).slice(0, 3);
  if (!choices.includes(correct)) choices[0] = correct;

  quizQuestion.textContent = correct.question;
  quizOptions.innerHTML = "";

  choices = choices.sort(() => 0.5 - Math.random());
  choices.forEach(choice => {
    const btn = document.createElement("button");
    btn.textContent = choice.answer;
    btn.onclick = () => {
      quizFeedback.textContent = choice === correct ? "✅ Correct!" : "❌ Wrong!";
    };
    quizOptions.appendChild(btn);
  });
}

nextQuizBtn.addEventListener("click", () => {
  quizFeedback.textContent = "";
  quizIndex = (quizIndex + 1) % flashcards.length;
  loadQuizQuestion();
});

// === Search ===
searchInput.addEventListener("input", () => {
  const query = searchInput.value.toLowerCase();
  searchResults.innerHTML = "";
  const results = flashcards.filter(card =>
    card.question.toLowerCase().includes(query) || card.answer.toLowerCase().includes(query)
  );
  results.forEach(card => {
    const li = document.createElement("li");
    li.textContent = `${card.question} — ${card.answer}`;
    searchResults.appendChild(li);
  });
});

// === Dashboard Navigation ===
function showSection(sectionId) {
  document.querySelectorAll('.section').forEach(section => {
    section.classList.add('hidden');
  });
  document.getElementById(sectionId).classList.remove('hidden');
  if (sectionId === 'quiz') loadQuizQuestion();
}

showCard(currentIndex);
showSection('flashcards');